<?php
error_reporting(0);
$connection=mysql_connect('127.0.0.1','root','');
mysql_select_db('pkm',$connection);
?>